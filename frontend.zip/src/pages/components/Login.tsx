const Login = () => {
  return (
    <div className="w-full max-w-6xl m-auto h-full flex justify-center items-center">
      <p>Please Login to Continue</p>
    </div>
  );
};

export default Login;
