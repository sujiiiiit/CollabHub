import Filters, { CategoryFilter } from "@/pages/components/filter";
import ForYou from "@/pages/components/forYou";

export default function App() {
  return (
    <>
    <div className="w-full max-w-6xl m-auto pt-4 px-4">
      <div className="flex items-center relative h-10 justify-start gap-3">
        <Filters />
        <CategoryFilter />
      </div>
      <ForYou />
      </div>
    </>
  );
}
